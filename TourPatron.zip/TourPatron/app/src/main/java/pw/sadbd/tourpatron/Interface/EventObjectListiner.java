package pw.sadbd.tourpatron.Interface;

import pw.sadbd.tourpatron.PojoClass.Event;

import java.util.List;

public interface EventObjectListiner {
    void getEvent(List<Event> eventList);
}
