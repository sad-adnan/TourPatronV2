package pw.sadbd.tourpatron.Interface;

public interface OnTestInterface {
    void test();
}
