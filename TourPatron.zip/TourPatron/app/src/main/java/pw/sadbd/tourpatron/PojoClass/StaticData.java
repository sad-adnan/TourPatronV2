package pw.sadbd.tourpatron.PojoClass;

public class StaticData {
    public static String eventID;
}
