package pw.sadbd.tourpatron.Interface;

public interface AuthenticationListiner_ {
    void goToPtofile();
    void goToLogin();
    void goToSignUp();
}
