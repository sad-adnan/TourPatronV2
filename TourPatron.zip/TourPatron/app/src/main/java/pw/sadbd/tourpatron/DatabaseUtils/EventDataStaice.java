package pw.sadbd.tourpatron.DatabaseUtils;

import pw.sadbd.tourpatron.PojoClass.Event;

import java.util.List;

public class EventDataStaice {
    public static List<Event> eventList;
}
