package pw.sadbd.tourpatron.Interface;

import com.google.android.gms.maps.model.LatLng;

public interface NearbyLiatiner  {
    void getLatlon(LatLng latLng);
}

