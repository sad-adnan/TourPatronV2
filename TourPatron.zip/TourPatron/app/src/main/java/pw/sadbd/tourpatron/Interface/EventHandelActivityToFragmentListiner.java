package pw.sadbd.tourpatron.Interface;

public interface EventHandelActivityToFragmentListiner {
    void getActivityStatus(String status);
}
