package pw.sadbd.tourpatron.trytodeleteevent;

public interface Eventdeletelistiner {
    void onDelete(String eventid);
}
